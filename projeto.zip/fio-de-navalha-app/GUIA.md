# Fio de Navalha: do jogo ao app na Google Play

Este pacote tem o jogo pronto para virar app Android (pasta `www`), a configuração do Capacitor e o botão "Assistir anúncio: +50 moedas" já encaixado na loja. Por enquanto o botão simula um anúncio. No app, ele usa o anúncio de teste do Google.

Importante: eu não consegui gerar o app nem testar o plugin de anúncios aqui. Os passos abaixo são para você fazer no seu computador. Confira os nomes e comandos na documentação oficial se algo tiver mudado.

## O que você precisa

- Um computador com Node.js e o Android Studio instalados.
- Uma conta de desenvolvedor da Google Play (taxa única, em torno de US$ 25).
- Uma conta no AdMob (admob.google.com), gratuita.

## 1. Gerar o projeto Android

Dentro desta pasta, no terminal:

```
npm init -y
npm i @capacitor/core @capacitor/android @capacitor-community/admob
npm i -D @capacitor/cli
npx cap add android
npx cap sync
npx cap open android
```

O último comando abre o Android Studio com o projeto. Antes de publicar, troque `com.seunome.fionavalha` em `capacitor.config.json` por um nome único seu (por exemplo `com.joaosilva.fionavalha`). Esse nome não pode mudar depois de publicado.

## 2. Ligar os anúncios (modo teste)

No Android Studio, abra `android/app/src/main/AndroidManifest.xml` e coloque dentro de `<application>`:

```
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-3940256099942544~3347511713"/>
```

Esse é o ID de teste do Google. O jogo já usa o anúncio de teste (`TEST_REWARDED` em `www/index.html`). Rode no seu celular (S24 com depuração USB ligada) e confira que o botão da loja mostra um anúncio e dá 50 moedas.

Nunca clique nos seus próprios anúncios reais nem use os IDs reais durante os testes. Isso pode suspender sua conta do AdMob.

## 3. Trocar pelos anúncios reais

1. No AdMob, cadastre o app e crie um bloco de anúncio "Premiado" (rewarded).
2. Substitua o ID de aplicativo no `AndroidManifest.xml` pelo seu.
3. Em `www/index.html`, troque o valor de `TEST_REWARDED` pelo ID do seu bloco.
4. Rode `npx cap sync` de novo.

## 4. Vender itens com dinheiro de verdade

Para itens digitais dentro de apps (pacotes de moedas, por exemplo), a Google exige o Google Play Billing. O jogo ainda não tem isso. Há plugins para Capacitor que fazem a ponte (por exemplo o `cordova-plugin-purchase` ou o RevenueCat), e os produtos são cadastrados no Play Console em "Monetizar > Produtos". Posso montar essa parte numa próxima etapa, mas ela só pode ser testada no app instalado pela Play (teste interno).

## 5. Publicar

1. No Android Studio: Build > Generate Signed Bundle (formato AAB). Guarde a chave de assinatura em lugar seguro, sem ela você não consegue atualizar o app.
2. No Play Console, crie o app e envie o AAB.
3. Preencha a política de privacidade (obrigatória quando há anúncios), a classificação de conteúdo e a declaração de anúncios.
4. Contas pessoais novas costumam precisar de um período de teste fechado com testadores antes de liberar para todos. Confira as regras atuais no Play Console.

## Dinheiro e impostos

Você precisa cadastrar um perfil de pagamentos para receber. A Google fica com uma comissão nas vendas dentro do app. Sobre imposto de renda, MEI ou outra forma de receber, converse com um contador.
